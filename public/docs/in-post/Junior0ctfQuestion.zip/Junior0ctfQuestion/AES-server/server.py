#!/usr/bin/env python
# coding=utf-8

import SocketServer
from Crypto.Cipher import AES

with open('secretkey', 'rb') as f:
    key = f.read()
with open('flag.txt') as f:
    flag = f.read()

class handler(SocketServer.BaseRequestHandler):

    def handle(self):
        self.request.send("Welcome to the perfect aes-cbc cryptosystem!(decrypt-only)\n")
        self.request.send("Please input your iv and encrypted message in hex:\n")
        
        data = self.request.recv(1024).rstrip()
        try:
            raw_data = data.decode('hex')
        except Exception, e:
            self.request.send("Error: {}\n".format(e.message))
            self.request.close()
            return

        if len(raw_data) < 32 or len(raw_data) & 0xf:
            self.request.send("Your input is not valid!\n")
            self.request.close()
            return
        
        iv = raw_data[:16]
        enc = raw_data[16:]
        cipher = AES.new(key, AES.MODE_CBC, iv)
        plain = cipher.decrypt(enc)
        self.request.send("Here is your plaintext: {}\n".format(repr(plain)))

        if plain[:5] == 'admin':
            self.request.send("hello, admin! Here is your flag: {}".format(flag))
        self.request.close()


if __name__ == "__main__":
    HOST, PORT = "localhost", 9999
    server = SocketServer.TCPServer((HOST, PORT), handler)
    server.serve_forever()
